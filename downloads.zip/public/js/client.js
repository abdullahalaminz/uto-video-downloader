document.addEventListener('DOMContentLoaded', () => {
    // --- Theme Toggler ---
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle?.querySelector('i');

    const savedTheme = localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');

    if (savedTheme === 'light') {
        document.documentElement.classList.add('theme-light');
        document.documentElement.classList.remove('theme-dark');
        if (themeIcon) themeIcon.classList.replace('fa-moon', 'fa-sun');
    } else {
        document.documentElement.classList.add('theme-dark');
        document.documentElement.classList.remove('theme-light');
        if (themeIcon) themeIcon.classList.replace('fa-sun', 'fa-moon');
    }
    
    themeToggle?.addEventListener('click', () => {
        const isLight = document.documentElement.classList.toggle('theme-light');
        document.documentElement.classList.toggle('theme-dark', !isLight);
        
        if (isLight) {
            themeIcon.classList.replace('fa-moon', 'fa-sun');
            localStorage.setItem('theme', 'light');
        } else {
            themeIcon.classList.replace('fa-sun', 'fa-moon');
            localStorage.setItem('theme', 'dark');
        }
    });

    // --- Index Page Form Loader ---
    const urlForm = document.getElementById('urlForm');
    if (urlForm) {
        const submitButton = document.getElementById('submitButton');
        const buttonIcon = submitButton.querySelector('i');

        urlForm.addEventListener('submit', () => {
            // Check if the form is valid (e.g., URL is not empty) before showing loader
            if (urlForm.checkValidity()) {
                submitButton.disabled = true;
                buttonIcon.classList.remove('fa-arrow-right');
                buttonIcon.classList.add('fa-spinner', 'fa-spin');
            }
        });
    }


    // --- Info Page Logic ---
    const downloadButton = document.getElementById('downloadButton');
    if (downloadButton) {
        // ... (rest of the info page logic remains unchanged)
        const videoUrl = downloadButton.dataset.url;
        let selectedFormat = null;
        let selectedQuality = null;

        // Add event listeners to format cards
        document.querySelectorAll('.format-card').forEach(card => {
            card.addEventListener('click', () => {
                // Remove previous selections
                document.querySelectorAll('.format-card.selected').forEach(c => c.classList.remove('selected'));
                
                // Select new card
                card.classList.add('selected');
                
                selectedFormat = card.dataset.format;
                selectedQuality = card.dataset.quality;
                
                downloadButton.disabled = false;
                downloadButton.innerHTML = `<i class="fas fa-download"></i> Download as ${selectedFormat.toUpperCase()}`;
            });
        });

        // Handle download button click
        downloadButton.addEventListener('click', () => {
            if (selectedFormat && selectedQuality && videoUrl) {
                // Disable options
                document.querySelectorAll('.format-card').forEach(c => c.style.pointerEvents = 'none');
                downloadButton.disabled = true;
                downloadButton.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Connecting...`;
                
                // Show progress bar
                const progressContainer = document.getElementById('progress-container');
                const progressBar = document.getElementById('progress-bar');
                const progressText = document.getElementById('progress-text');
                progressContainer.style.display = 'block';
                progressBar.style.width = '0%';
                progressText.textContent = 'Initializing download...';

                // Establish WebSocket connection
                const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
                const socket = new WebSocket(`${protocol}//${window.location.host}`);

                socket.onopen = () => {
                    console.log('WebSocket connected. Sending download request.');
                    downloadButton.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Preparing...`;
                    const payload = { videoURL: videoUrl, format: selectedFormat, quality: selectedQuality };
                    socket.send(JSON.stringify({ type: 'startDownload', payload }));
                };

                socket.onmessage = (event) => {
                    const data = JSON.parse(event.data);

                    switch (data.type) {
                        case 'progress':
                            const percentage = Math.round(data.value);
                            progressBar.style.width = `${percentage}%`;
                            progressText.textContent = `Downloading... ${percentage}%`;
                            downloadButton.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Downloading...`;
                            break;
                        case 'complete':
                            progressBar.style.width = '100%';
                            progressText.textContent = 'Download complete! Your file will start downloading automatically.';
                            downloadButton.innerHTML = `<i class="fas fa-check-circle"></i> Complete`;
                            downloadButton.style.backgroundColor = 'var(--success)';
                            // Trigger the file download
                            window.location.href = data.fileUrl;
                            socket.close();
                            break;
                        case 'error':
                            progressText.textContent = `Error: ${data.message}`;
                            progressText.style.color = 'var(--error)';
                            downloadButton.innerHTML = `<i class="fas fa-times-circle"></i> Failed`;
                            downloadButton.style.backgroundColor = 'var(--error)';
                            break;
                         case 'log':
                            console.log('Server log:', data.message);
                            break;
                    }
                };

                socket.onclose = () => {
                    console.log('WebSocket disconnected.');
                    // Re-enable button if download didn't complete
                    if (!progressText.textContent.includes('complete')) {
                         downloadButton.disabled = false;
                         document.querySelectorAll('.format-card').forEach(c => c.style.pointerEvents = 'auto');
                    }
                };

                socket.onerror = (error) => {
                    console.error('WebSocket Error:', error);
                    progressText.textContent = 'A connection error occurred. Please try again.';
                    progressText.style.color = 'var(--error)';
                    downloadButton.innerHTML = `<i class="fas fa-times-circle"></i> Connection Failed`;
                };
            }
        });
    }
});