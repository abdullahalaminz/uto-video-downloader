const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const util = require('util');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const execPromise = util.promisify(exec);

// 📁 Create downloads directory if not exists
const downloadsDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
  fs.mkdirSync(downloadsDir);
}

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // To parse JSON bodies

// 🌐 Home Page
app.get('/', (req, res) => {
  res.render('index');
});

// 📋 Get Video Info and Show Options
app.post('/info', async (req, res) => {
  const videoURL = req.body.url;
  if (!videoURL) {
    return res.status(400).render('error', { message: 'No URL provided. Please go back and enter a valid YouTube URL.' });
  }

  try {
    const { stdout } = await execPromise(`yt-dlp --dump-json --no-warnings "${videoURL}"`);
    const videoInfo = JSON.parse(stdout);
    
    res.render('info', {
      title: videoInfo.title,
      thumbnail: videoInfo.thumbnail,
      url: videoURL,
      duration: formatDuration(videoInfo.duration),
      uploader: videoInfo.uploader,
    });
  } catch (error) {
    console.error('Error fetching video info:', error);
    res.status(500).render('error', { message: 'Could not retrieve video information. The URL might be invalid, private, or geo-restricted. Please check the console for details.' });
  }
});

// WebSocket connection handler
wss.on('connection', (ws) => {
  console.log('Client connected to WebSocket');
  
  ws.on('message', (message) => {
    const data = JSON.parse(message);

    if (data.type === 'startDownload') {
      startDownload(ws, data.payload);
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

function startDownload(ws, { videoURL, format, quality }) {
  console.log(`Starting download for: ${videoURL} [${format}@${quality}]`);

  const sanitizedTitle = (Math.random().toString(36).substring(2, 15)); // Create a random name to avoid issues with special characters
  const filename = `${sanitizedTitle}-${Date.now()}.${format}`;
  const filePath = path.join(downloadsDir, filename);

  const args = [
    '--progress', // Enable progress reporting
    '--no-warnings',
    '-o', filePath
  ];

  if (format === 'mp3') {
    args.push('-x', '--audio-format', 'mp3', '--audio-quality', '0');
  } else {
    let filter = 'best';
    if (quality === '720') filter = 'bestvideo[height<=720]+bestaudio/best[height<=720]';
    else if (quality === '480') filter = 'bestvideo[height<=480]+bestaudio/best[height<=480]';
    else if (quality === '360') filter = 'bestvideo[height<=360]+bestaudio/best[height<=360]';
    args.push('-f', filter);
  }
  
  args.push(videoURL);
  
  const ytDlp = spawn('yt-dlp', args);

  ytDlp.stdout.on('data', (data) => {
    const output = data.toString();
    console.log(output); // Log yt-dlp output for debugging

    // Regex to capture progress percentage
    const progressMatch = output.match(/\[download\]\s+([\d\.]+)%/);
    if (progressMatch && progressMatch[1]) {
      const percentage = parseFloat(progressMatch[1]);
      ws.send(JSON.stringify({ type: 'progress', value: percentage }));
    }
  });

  ytDlp.stderr.on('data', (data) => {
    console.error(`yt-dlp stderr: ${data}`);
    // Optionally send stderr to client for debugging
    ws.send(JSON.stringify({ type: 'log', message: data.toString() }));
  });

  ytDlp.on('close', (code) => {
    if (code === 0) {
      console.log('Download completed successfully.');
      ws.send(JSON.stringify({ type: 'complete', fileUrl: `/serve/${filename}` }));
    } else {
      console.error(`yt-dlp process exited with code ${code}`);
      ws.send(JSON.stringify({ type: 'error', message: 'Download failed. Check server logs for details. Make sure FFmpeg is installed for audio conversion.' }));
      // Clean up failed download
      if (fs.existsSync(filePath)) {
        fs.unlink(filePath, (err) => {
          if (err) console.error('Failed to clean up file:', err);
        });
      }
    }
  });
  
  ws.on('close', () => {
    // If the client disconnects, kill the child process to stop the download
    console.log('Client disconnected, terminating download process.');
    ytDlp.kill();
  });
}

// SERVE FILE FOR DOWNLOAD
app.get('/serve/:filename', (req, res) => {
    const filename = req.params.filename;
    // Security: Sanitize filename to prevent path traversal
    const safeFilename = path.basename(filename);
    const filePath = path.join(downloadsDir, safeFilename);

    if (fs.existsSync(filePath)) {
        res.download(filePath, (err) => {
            if (err) {
                console.error('Error sending file:', err);
            }
            // Cleanup: delete the file after it has been sent
            fs.unlink(filePath, (unlinkErr) => {
                if (unlinkErr) {
                    console.error('Error cleaning up file:', unlinkErr);
                } else {
                    console.log('Successfully cleaned up file:', safeFilename);
                }
            });
        });
    } else {
        res.status(404).render('error', { message: 'File not found. It may have been already downloaded or an error occurred.' });
    }
});


// ⏱️ Format seconds as mm:ss
function formatDuration(seconds) {
  if (!seconds) return 'N/A';
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`✅ Server started on http://localhost:${PORT}`));